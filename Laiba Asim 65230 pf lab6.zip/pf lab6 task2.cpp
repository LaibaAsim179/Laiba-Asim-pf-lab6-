#include<iostream>
using namespace std;
int main()
{
	float n;
	float sum=0;
	int i=0;
	float average;
	do
	{
		
		cout<<"enter a number"<<endl;
		cin>>n;
		sum+=n;
		i++;
	
	}
	while(i<5);
	average=sum/4;
	cout<<"average"<<average<<endl;
	return 0;
}