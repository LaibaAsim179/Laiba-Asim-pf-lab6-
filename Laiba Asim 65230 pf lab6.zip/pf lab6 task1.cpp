#include<iostream>
using namespace std;
int main()
{
	float password;
	int i=1;
	
	while(i>0)
	{
		cout<<"enter the password"<<endl;
		cin>>password;
		i++;
		if(password==12345)
		{
			cout<<"login successful"<<endl;
		}
		else 
		{
			break;
		}
	}
	return 0;
}